from setuptools import setup

setup(
    name='envelope',
    version='0.1',
    author='DDS Accelerators',
    packages=['envelope'],
    install_requires=[
        'googleapis-common-protos',
    ]
)

